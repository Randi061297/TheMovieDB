# The-Movie-Show
UAS WAHYUNI
![Detail TV Show](https://github.com/wahyunisiregar/The-Movie-Show/blob/master/hasil%20program/movie%20(1).png)
![Movie Catalog1](https://github.com/wahyunisiregar/The-Movie-Show/blob/master/hasil%20program/movie%20(2).png)
![Movie Catalog2](https://github.com/wahyunisiregar/The-Movie-Show/blob/master/hasil%20program/movie%20(3).png)
![Movie Catalog3](https://github.com/wahyunisiregar/The-Movie-Show/blob/master/hasil%20program/movie%20(4).png)
![Detail Movie Show](https://github.com/wahyunisiregar/The-Movie-Show/blob/master/hasil%20program/movie%20(5).png)
![TV Show 1](https://github.com/wahyunisiregar/The-Movie-Show/blob/master/hasil%20program/movie%20(6).png)
![TV Show 2](https://github.com/wahyunisiregar/The-Movie-Show/blob/master/hasil%20program/movie%20(7).png)

